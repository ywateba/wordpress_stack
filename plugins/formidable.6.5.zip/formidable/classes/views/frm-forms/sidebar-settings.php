<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

_deprecated_file( esc_html( basename( __FILE__ ) ), '4.0', 'formidable/classes/views/frm-forms/mb_insert_fields.php' );

include FrmAppHelper::plugin_path() . '/classes/views/frm-forms/mb_insert_fields.php';
